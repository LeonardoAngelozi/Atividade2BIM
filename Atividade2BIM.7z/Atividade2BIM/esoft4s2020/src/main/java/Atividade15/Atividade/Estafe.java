package Atividade15.Atividade;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;

@Entity
public class Estafe{
    @ManyToMany
    private String nomeEstafe;
    private String sobrenomeEstafe;
    @OneToOne(mappedBy = "endereco")
    private Endereco endereco;

    public String getNomeEstafe() {
        return nomeEstafe;
    }

    public String getSobrenomeEstafe() {
        return sobrenomeEstafe;
    }

    public void setNomeEstafe(String nomeEstafe) {
        this.nomeEstafe = nomeEstafe;
    }

    public void setSobrenomeEstafe(String sobrenomeEstafe) {
        this.sobrenomeEstafe = sobrenomeEstafe;
    }

}
