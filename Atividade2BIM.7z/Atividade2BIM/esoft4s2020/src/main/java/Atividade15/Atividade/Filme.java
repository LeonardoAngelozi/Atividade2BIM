package Atividade15.Atividade;

import javax.persistence.Entity;

@Entity
public class Filme {
    public String nomeDoFilme;
    public String descricaoDoFilme;

    public Filme(String nomeDoFilme, String descricaoDoFilme) {
        this.nomeDoFilme = nomeDoFilme;
        this.descricaoDoFilme = descricaoDoFilme;
    }

    
}
