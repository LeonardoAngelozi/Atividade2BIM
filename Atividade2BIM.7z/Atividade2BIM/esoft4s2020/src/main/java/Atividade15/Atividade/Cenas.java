package Atividade15.Atividade;

import javax.persistence.Entity;

@Entity
public class Cenas {
    private String nomeDaCena;
    private int numeroDaCena;
    private int numeroDeCenas;

    public String getNomeDaCena() {
        return nomeDaCena;
    }

    public int getNumeroDaCena() {
        return numeroDaCena;
    }

    public int getNumeroDeCenas() {
        return numeroDeCenas;
    }
    public void setNomeDaCena(String nomeDaCena) {
        this.nomeDaCena = nomeDaCena;
    }

    public void setNumeroDaCena(int numeroDaCena) {
        this.numeroDaCena = numeroDaCena;
    }
    
    public void setNumeroDeCenas(int numeroDeCenas) {
        this.numeroDeCenas = numeroDeCenas;
    }

}
