package Atividade15.Atividade;

import javax.persistence.Entity;

@Entity
public class Ator extends Estafe{
    private String papelNoFilme;

    public Ator() {
        super();
    }

    public String getPapelNoFilme() {
        return papelNoFilme;
    }

    public void setPapelNoFilme(String papelNoFilme) {
        this.papelNoFilme = papelNoFilme;
    }

}