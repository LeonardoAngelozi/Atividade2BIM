package Atividade15.Atividade;

import javax.persistence.Entity;

@Entity
public class Editor extends Estafe{
    private String especialidade;

    public Editor() {
        super();
    }
    
    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }
}
