package Atividade15.Atividade;

import javax.persistence.Entity;

@Entity
public class Diretor extends Estafe{
    private String tecnicaDeFilmagemFavorita;

    public Diretor(){
        super();
    }

    public String getTecnicaDeFilmagemFavorita() {
        return tecnicaDeFilmagemFavorita;
    }

    public void setTecnicaDeFilmagemFavorita(String tecnicaDeFilmagemFavorita) {
        this.tecnicaDeFilmagemFavorita = tecnicaDeFilmagemFavorita;
    }

}
