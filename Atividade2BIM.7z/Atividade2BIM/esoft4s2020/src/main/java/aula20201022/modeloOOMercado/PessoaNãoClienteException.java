package aula20201022.modeloOOMercado;

public class PessoaNãoClienteException extends RuntimeException {

	public PessoaNãoClienteException(String message) {
        super(message);
	}

}
